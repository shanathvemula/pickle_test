from .main import Ui_MainWindow
from .Load import load